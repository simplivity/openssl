/* fips/ecdsa/fips_ecdsa_selftest.c */
/* Written by Dr Stephen N Henson (steve@openssl.org) for the OpenSSL
 * project 2011.
 */
/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 */

#define OPENSSL_FIPSAPI

#include <string.h>
#include <openssl/crypto.h>
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/fips.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/bn.h>

#ifdef OPENSSL_FIPS

__fips_constseg
static const char P_256_name[] = "ECDSA P-256";


__fips_constseg
static const unsigned char P_256_d[] = {
	0x4C,0x33,0xF7,0x2D,0xCA,0x13,0xA4,0x35,0xA8,0x69,0x40,0x34,
	0xE9,0x64,0xF0,0x25,0x25,0x8D,0xF6,0x34,0xA2,0xB7,0x6F,0xAB,
	0x8D,0x1E,0xE5,0x37,0x42,0xCC,0x1E,0xCB
};
__fips_constseg
static const unsigned char P_256_qx[] = {
	0x10,0x5F,0xA6,0x0C,0xC2,0x0C,0xD7,0xAD,0x26,0xA1,0xEB,0x94,
	0x5E,0x67,0xB1,0x4F,0x7A,0x7C,0x49,0xBC,0xBB,0x51,0x39,0x70,
	0x58,0x34,0x07,0x4D,0xE9,0xDE,0x0E,0xA3
};
__fips_constseg
static const unsigned char P_256_qy[] = {
	0x33,0xCF,0x0F,0x48,0x1A,0x46,0x71,0x37,0x0D,0x0F,0x64,0x37,
	0x87,0x48,0x7B,0x07,0x74,0xEB,0xA7,0x6C,0xC1,0xF8,0xB9,0xDF,
	0x45,0xA2,0x3B,0x62,0xEF,0xDB,0x7D,0x94
};

typedef struct 
	{
	int curve;
	const char *name;
	const unsigned char *x;
	size_t xlen;
	const unsigned char *y;
	size_t ylen;
	const unsigned char *d;
	size_t dlen;
	} EC_SELFTEST_DATA;

#define make_ecdsa_test(nid, pr) { nid, pr##_name, \
				pr##_qx, sizeof(pr##_qx), \
				pr##_qy, sizeof(pr##_qy), \
				pr##_d, sizeof(pr##_d)}

static EC_SELFTEST_DATA test_ec_data[] = 
	{
	make_ecdsa_test(NID_X9_62_prime256v1, P_256),
	};

int FIPS_selftest_ecdsa()
	{
	EC_KEY *ec = NULL;
	BIGNUM *x = NULL, *y = NULL, *d = NULL;
	EVP_PKEY pk;
	int rv = 0;
	size_t i;

	for (i = 0; i < sizeof(test_ec_data)/sizeof(EC_SELFTEST_DATA); i++)
		{
		EC_SELFTEST_DATA *ecd = test_ec_data + i;

		x = BN_bin2bn(ecd->x, ecd->xlen, x);
		y = BN_bin2bn(ecd->y, ecd->ylen, y);
		d = BN_bin2bn(ecd->d, ecd->dlen, d);

		if (!x || !y || !d)
			goto err;

		ec = EC_KEY_new_by_curve_name(ecd->curve);
		if (!ec)
			goto err;

		if (!EC_KEY_set_public_key_affine_coordinates(ec, x, y))
			goto err;

		if (!EC_KEY_set_private_key(ec, d))
			goto err;

		pk.type = EVP_PKEY_EC;
		pk.pkey.ec = ec;

		if (!fips_pkey_signature_test(FIPS_TEST_SIGNATURE, &pk, NULL, 0,
						NULL, 0, EVP_sha512(), 0,
						ecd->name))
			goto err;
		EC_KEY_free(ec);
		ec = NULL;
		}

	rv = 1;

	err:

	if (x)
		BN_clear_free(x);
	if (y)
		BN_clear_free(y);
	if (d)
		BN_clear_free(d);
	if (ec)
		EC_KEY_free(ec);

	return rv;

	}

#endif
