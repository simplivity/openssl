/* fips/ecdh/fips_ecdh_selftest.c */
/* Written by Dr Stephen N Henson (steve@openssl.org) for the OpenSSL
 * project 2011.
 */
/* ====================================================================
 * Copyright (c) 2011 The OpenSSL Project.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer. 
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. All advertising materials mentioning features or use of this
 *    software must display the following acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit. (http://www.OpenSSL.org/)"
 *
 * 4. The names "OpenSSL Toolkit" and "OpenSSL Project" must not be used to
 *    endorse or promote products derived from this software without
 *    prior written permission. For written permission, please contact
 *    licensing@OpenSSL.org.
 *
 * 5. Products derived from this software may not be called "OpenSSL"
 *    nor may "OpenSSL" appear in their names without prior written
 *    permission of the OpenSSL Project.
 *
 * 6. Redistributions of any form whatsoever must retain the following
 *    acknowledgment:
 *    "This product includes software developed by the OpenSSL Project
 *    for use in the OpenSSL Toolkit (http://www.OpenSSL.org/)"
 *
 * THIS SOFTWARE IS PROVIDED BY THE OpenSSL PROJECT ``AS IS'' AND ANY
 * EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE OpenSSL PROJECT OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * ====================================================================
 *
 */

#define OPENSSL_FIPSAPI

#include <string.h>
#include <openssl/crypto.h>
#include <openssl/ec.h>
#include <openssl/ecdh.h>
#include <openssl/fips.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/bn.h>

#ifdef OPENSSL_FIPS

#include "fips_locl.h"

__fips_constseg
static const unsigned char p256_qcavsx[] = {
    0xC4,0xF0,0x8A,0x67,0x9D,0x6B,0xAB,0x7E,0xC6,0x2D,0xD1,0x19,
    0x28,0x03,0x90,0x37,0x8B,0x96,0x7A,0xB2,0xEA,0x5C,0x56,0x58,
    0x08,0x88,0x5F,0xD5,0x08,0x8C,0x59,0x5D
};
__fips_constseg
static const unsigned char p256_qcavsy[] = {
    0x6A,0xEE,0x4E,0x00,0x4D,0x0A,0x77,0xD3,0x0F,0x75,0xD6,0x07,
    0xC5,0x16,0x6A,0x62,0x2A,0xC3,0xA0,0x0D,0x96,0x41,0xCE,0xA4,
    0x29,0x2F,0x5D,0x89,0xF9,0x19,0x45,0x6C
};
__fips_constseg
static const unsigned char p256_qiutx[] = {
    0xAB,0x7B,0xC4,0xD4,0x93,0x28,0xF4,0x2D,0x7A,0xC3,0xEB,0x32,
    0x2A,0x2D,0x3A,0x9D,0x04,0x75,0x18,0x44,0xE9,0x73,0xCF,0xCF,
    0xFE,0xF5,0x10,0x15,0x96,0xF6,0x00,0x56
};
__fips_constseg
static const unsigned char p256_qiuty[] = {
    0x88,0xC9,0x76,0x9F,0x86,0x83,0x2E,0xE7,0x43,0x70,0x92,0x3B,
    0x4E,0x0F,0xC7,0x45,0xC6,0x44,0xAC,0x9F,0xD8,0x83,0xBF,0x4B,
    0x22,0x69,0xDB,0xD2,0x10,0xBB,0x0F,0x0D
};
__fips_constseg
static const unsigned char p256_qiutd[] = {
    0x2B,0x35,0xC1,0xF8,0xAA,0xCA,0x1C,0xFC,0x4A,0xC5,0x7B,0x1E,
    0xE5,0xBA,0xF7,0x34,0x2D,0xC4,0xEA,0x31,0x9A,0x6A,0x29,0x64,
    0xF8,0xB6,0x7B,0xBE,0x3F,0xA2,0x4B,0xE3
};
__fips_constseg
static const unsigned char p256_ziut[] = {
    0xFC,0x21,0xBB,0x27,0xC3,0xC1,0x6A,0xBB,0x1B,0x48,0x9D,0x90,
    0xD5,0x91,0x13,0x61,0x7E,0xE0,0x4E,0xED
};

typedef struct 
	{
	int curve;
	const unsigned char *x1;
	size_t x1len;
	const unsigned char *y1;
	size_t y1len;
	const unsigned char *d1;
	size_t d1len;
	const unsigned char *x2;
	size_t x2len;
	const unsigned char *y2;
	size_t y2len;
	const unsigned char *z;
	size_t zlen;
	} ECDH_SELFTEST_DATA;

#define make_ecdh_test(nid, pr) { nid, \
				pr##_qiutx, sizeof(pr##_qiutx), \
				pr##_qiuty, sizeof(pr##_qiuty), \
				pr##_qiutd, sizeof(pr##_qiutd), \
				pr##_qcavsx, sizeof(pr##_qcavsx), \
				pr##_qcavsy, sizeof(pr##_qcavsy), \
				pr##_ziut, sizeof(pr##_ziut) }

static ECDH_SELFTEST_DATA test_ecdh_data[] = 
	{
	make_ecdh_test(NID_X9_62_prime256v1, p256),
	};

int FIPS_selftest_ecdh(void)
	{
	EC_KEY *ec1 = NULL, *ec2 = NULL;
	const EC_POINT *ecp = NULL;
	BIGNUM *x = NULL, *y = NULL, *d = NULL;
	unsigned char *ztmp = NULL;
	int rv = 1;
	size_t i;

	for (i = 0; i < sizeof(test_ecdh_data)/sizeof(ECDH_SELFTEST_DATA); i++)
		{
		ECDH_SELFTEST_DATA *ecd = test_ecdh_data + i;
		if (!fips_post_started(FIPS_TEST_ECDH, ecd->curve, 0))
			continue;
		ztmp = OPENSSL_malloc(ecd->zlen);

		x = BN_bin2bn(ecd->x1, ecd->x1len, x);
		y = BN_bin2bn(ecd->y1, ecd->y1len, y);
		d = BN_bin2bn(ecd->d1, ecd->d1len, d);

		if (!x || !y || !d || !ztmp)
			{
			rv = -1;
			goto err;
			}

		ec1 = EC_KEY_new_by_curve_name(ecd->curve);
		if (!ec1)
			{
			rv = -1;
			goto err;
			}
		EC_KEY_set_flags(ec1, EC_FLAG_COFACTOR_ECDH);

		if (!EC_KEY_set_public_key_affine_coordinates(ec1, x, y))
			{
			rv = -1;
			goto err;
			}

		if (!EC_KEY_set_private_key(ec1, d))
			{
			rv = -1;
			goto err;
			}

		x = BN_bin2bn(ecd->x2, ecd->x2len, x);
		y = BN_bin2bn(ecd->y2, ecd->y2len, y);

		if (!x || !y)
			{
			rv = -1;
			goto err;
			}

		ec2 = EC_KEY_new_by_curve_name(ecd->curve);
		if (!ec2)
			{
			rv = -1;
			goto err;
			}
		EC_KEY_set_flags(ec1, EC_FLAG_COFACTOR_ECDH);

		if (!EC_KEY_set_public_key_affine_coordinates(ec2, x, y))
			{
			rv = -1;
			goto err;
			}

		ecp = EC_KEY_get0_public_key(ec2);
		if (!ecp)
			{
			rv = -1;
			goto err;
			}

		if (!ECDH_compute_key(ztmp, ecd->zlen, ecp, ec1, 0))
			{
			rv = -1;
			goto err;
			}

		if (!fips_post_corrupt(FIPS_TEST_ECDH, ecd->curve, NULL))
			ztmp[0] ^= 0x1;

		if (memcmp(ztmp, ecd->z, ecd->zlen))
			{
			fips_post_failed(FIPS_TEST_ECDH, ecd->curve, 0);
			rv = 0;
			}
		else if (!fips_post_success(FIPS_TEST_ECDH, ecd->curve, 0))
			goto err;

		EC_KEY_free(ec1);
		ec1 = NULL;
		EC_KEY_free(ec2);
		ec2 = NULL;
		OPENSSL_free(ztmp);
		ztmp = NULL;
		}

	err:

	if (x)
		BN_clear_free(x);
	if (y)
		BN_clear_free(y);
	if (d)
		BN_clear_free(d);
	if (ec1)
		EC_KEY_free(ec1);
	if (ec2)
		EC_KEY_free(ec2);
	if (ztmp)
		OPENSSL_free(ztmp);

	return rv;

	}

#endif
