/* fips_rsa2gtest.c */

#define OPENSSL_FIPSAPI

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/err.h>
#include <openssl/bn.h>

#ifndef OPENSSL_FIPS

int main(int argc, char *argv[])
{
    printf("No FIPS RSA support\n");
    return(0);
}

#else

#include <openssl/rsa.h>
#include <openssl/fips.h>
#include "fips_utl.h"

int rsa_test(FILE *out, FILE *in);
static int rsa_genkey(FILE *out, int keylen, int count);


/*
 * This module is designed to process CAVS request files for
 * FIPS 186-4 RSA2 key generation using method B.3.3 with a fixed
 * exponent and both the C.2 and C.3 tables selected.  Both 2048
 * and 3072 key sizes are supported.
 *
 * The CAVS generated file name for the request is KeyGen_RandomProbablyPrime3_3.req
 */

#ifdef FIPS_ALGVS
int fips_rsagtest_main(int argc, char **argv)
#else
int main(int argc, char **argv)
#endif
{
    FILE *in = NULL, *out = NULL;

    int ret = 1;

    fips_algtest_init();

    if (argc == 1)
        in = stdin;
    else
        in = fopen(argv[1], "r");

    if (argc < 2)
        out = stdout;
    else
        out = fopen(argv[2], "w");

    if (!in)
    {
        fprintf(stderr, "FATAL input initialization error\n");
        goto end;
    }

    if (!out)
    {
        fprintf(stderr, "FATAL output initialization error\n");
        goto end;
    }

    if (!rsa_test(out, in))
    {
        fprintf(stderr, "FATAL RSAGTEST file processing error\n");
        goto end;
    }
    else
        ret = 0;

end:

    if (in && (in != stdin))
        fclose(in);
    if (out && (out != stdout))
        fclose(out);

    return ret;

}

#define RSA_TEST_MAXLINELEN 10240

int rsa_test(FILE *out, FILE *in)
{
    char *linebuf, *olinebuf, *p, *q;
    char *keyword, *value;
    int ret = 0;
    int lnum = 0;
    int genkey = 0;
    int keylen = -1;
    int count = 0;

    olinebuf = OPENSSL_malloc(RSA_TEST_MAXLINELEN);
    linebuf = OPENSSL_malloc(RSA_TEST_MAXLINELEN);

    if (!linebuf || !olinebuf)
        goto error;

    while (fgets(olinebuf, RSA_TEST_MAXLINELEN, in))
    {
        lnum++;
        strcpy(linebuf, olinebuf);
        keyword = linebuf;
        /* Skip leading space */
        while (isspace((unsigned char)*keyword))
            keyword++;

        /* Look for = sign */
        p = strchr(linebuf, '=');

        /* If no = or starts with [ (for [foo = bar] line) just copy */
        if (!p)
        {
            if (fputs(olinebuf, out) < 0)
                goto error;
            continue;
        }

        q = p - 1;

        /* Remove trailing space */
        while (isspace((unsigned char)*q))
            *q-- = 0;

        *p = 0;
        value = p + 1;

        /* Remove leading space from value */
        while (isspace((unsigned char)*value))
            value++;

        /* Remove trailing space from value */
        p = value + strlen(value) - 1;

        while (*p == '\n' || isspace((unsigned char)*p))
            *p-- = 0;

        /* Look for [mod = XXX] for key length */
        if (!strcmp(keyword, "[mod"))
        {
            genkey = 0;
            p = value + strlen(value) - 1;
            if (*p != ']') goto parse_error;
            *p = 0;
            keylen = atoi(value);
            if (keylen < 0) goto parse_error;
            fputs(olinebuf, out);
        }
        else if (!strncmp(keyword, "[Table", 6))
        {
            fputs(olinebuf, out);
        } 
        else if (!strcmp(keyword, "N")) 
        {
            count = atoi(value); 
            genkey = 1;
        }
        else continue;

        if (genkey)
        {
            if (!rsa_genkey(out, keylen, count))
                goto error;
        }

    }

    ret = 1;

error:

    if (olinebuf)
        OPENSSL_free(olinebuf);
    if (linebuf)
        OPENSSL_free(linebuf);

    return ret;

parse_error:

    fprintf(stderr, "FATAL parse error processing line %d\n", lnum);

    goto error;

}

static int rsa_genkey(FILE *out, int keylen, int count)
{
    int ret = 0;
    int i;
    RSA *rsa = NULL;
    BIGNUM *e = NULL;

    e = BN_new();
    if (!e) goto error;
    BN_set_word(e, 0x10001);

    for (i=0; i<count; i++) 
    {
        fputs("\r\n", out);
        rsa = FIPS_rsa_new();
        if (!rsa) goto error;
        FIPS_rsa_generate_key_ex(rsa, keylen, e, NULL);
        do_bn_print_name(out, "e", rsa->e);
        do_bn_print_name(out, "p", rsa->p);
        do_bn_print_name(out, "q", rsa->q);
        do_bn_print_name(out, "n", rsa->n);
        do_bn_print_name(out, "d", rsa->d);
        FIPS_rsa_free(rsa);
        rsa = NULL;
    }

    ret = 1;

error:
    if (rsa) FIPS_rsa_free(rsa);
    if (e) BN_free(e);

    return ret;
}

#endif
